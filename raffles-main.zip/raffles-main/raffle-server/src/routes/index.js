import routerx from 'express-promise-router'
import {
    create, get, buy, getWinner, checkNFT, createUser, updateUserWallet
} from '../controllers/raffleController'
const router = routerx()

router.post('/create-user', createUser);
router.post('/check-wallet', updateUserWallet);
router.post('/create', create);
router.get('/get', get);
router.post('/get_winner', getWinner);
router.post('/buy', buy);
router.post('/check-id', checkNFT);

export default router