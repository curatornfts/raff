module.exports = {
    dir: __dirname + "/src",
    dirname: __dirname
}